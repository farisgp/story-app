const CONFIG = {
  BASE_URL: "https://story-api.dicoding.dev/v1",
  MAP_SERVICE_API_KEY: "iIlJP7uMNKgjDJMnGNdR",
};

export default CONFIG;
