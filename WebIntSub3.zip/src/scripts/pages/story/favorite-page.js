
import FavoritePresenter from "./favorite-presenter";

class FavoritePage {
  #presenter = null;

  async render() {
    return '<div id="home-container"></div>';
  }

  async afterRender() {
    const container = document.querySelector("#home-container");
    container.innerHTML = this.#getTemplate();

    // this.#presenter = new FavoritePresenter({
    //   showLoading: this.showLoading.bind(this),
    //   hideLoading: this.hideLoading.bind(this),
    //   showError: this.showError.bind(this),
    //   renderStories: this.renderStories.bind(this)
    // });

    // await this.#presenter.loadStories();
    this.#presenter = new FavoritePresenter(this);
    await this.#presenter.initialize();
  }

  #getTemplate() {
    return `
      <section class="container">
        <h1>Dicoding Story</h1>
        <div id="stories-container" class="stories-grid"></div>
        <div id="loading-indicator" class="loading-indicator">Loading favorite stories...</div>
        <div id="error-message" class="error-message" style="display: none;"></div>
      </section>
    `;
  }

  get storiesContainer() {
    return document.querySelector("#stories-container");
  }

  get loadingIndicator() {
    return document.querySelector("#loading-indicator");
  }

  get errorMessage() {
    return document.querySelector("#error-message");
  }

  showLoading() {
    this.loadingIndicator.style.display = "block";
    this.storiesContainer.innerHTML = "";
    this.errorMessage.style.display = "none";
  }

  hideLoading() {
    this.loadingIndicator.style.display = "none";
  }

  showError(message) {
    this.errorMessage.textContent = `Error: ${message}`;
    this.errorMessage.style.display = "block";
  }

  renderStories(stories) {
    this.storiesContainer.innerHTML = "";
    if (stories.length === 0) {
      this.storiesContainer.innerHTML = "<p>Belum ada story.</p>";
      return;
    }

    stories.forEach(async (story) => {
      const isFavorite = await isStoryFavorite(story.id);

      const storyWrapper = document.createElement("div");
      storyWrapper.classList.add("story-item");
      storyWrapper.innerHTML = `
        <img src="${story.photoUrl}" alt="${story.name}'s story photo" class="story-photo">
        <div class="story-content">
          <h2 class="story-name">${story.name}</h2>
          <p class="story-date">${showFormattedDate(story.createdAt)}</p>
          <p class="story-description">${story.description}</p>
          ${
            story.lat && story.lon
              ? `<p class="story-location">Lokasi: ${story.lat}, ${story.lon}</p>`
              : ""
          }
          <button class="favorite-button">
            ${isFavorite ? "💔 Remove from Favorite" : "❤️ Add to Favorite"}
          </button>
        </div>
      `;

      const favButton = storyWrapper.querySelector(".favorite-button");
      favButton.addEventListener("click", async () => {
        const isNowFavorite = await isStoryFavorite(story.id);
        if (isNowFavorite) {
          await removeFavoriteStory(story.id);
          favButton.textContent = "❤️ Add to Favorite";
        } else {
          await addFavoriteStory(story);
          favButton.textContent = "💔 Remove from Favorite";
        }
      });

      this.storiesContainer.appendChild(storyWrapper);
    });
  }

}

export default FavoritePage;
