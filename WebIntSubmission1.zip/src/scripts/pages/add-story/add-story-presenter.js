import { addStory } from "../../data/api";
import L from "leaflet";

class AddStoryPresenter {
  #view;
  #onAddStorySuccess;
  #onAddStoryError;

  constructor({ view, onAddStorySuccess, onAddStoryError }) {
    this.#view = view;
    this.#onAddStorySuccess = onAddStorySuccess;
    this.#onAddStoryError = onAddStoryError;
  }

  async handleAddStory(data) {
    this.#view.showLoading();
    try {
      const token = localStorage.getItem("userToken");
      if (!token) throw new Error("Anda harus login untuk menambah story.");

      const response = await addStory({ ...data, token });
      if (response.error) {
        this.#onAddStoryError?.(response.message);
      } else {
        this.#onAddStorySuccess?.();
      }
    } catch (err) {
      this.#onAddStoryError?.(err.message);
    } finally {
      this.#view.hideLoading();
    }
  }

  initMapAndCamera(maptilerApiKey) {
    const map = L.map("add-story-map").setView([0, 0], 2);
    const mapTilerUrl = `https://api.maptiler.com/maps/streets-v2/{z}/{x}/{y}.png?key=${maptilerApiKey}`;
    L.tileLayer(mapTilerUrl, {
      attribution:
        '<a href="https://www.maptiler.com/" target="_blank">MapTiler</a> &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
    }).addTo(map);

    map.on("click", (e) => {
      this.#view.updateCoordinatesDisplay(e.latlng.lat, e.latlng.lng);
      this.#view.setMapMarker(e.latlng, `Lokasi: ${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`);
    });

    map.on("locationfound", (e) => {
      this.#view.updateCoordinatesDisplay(e.latlng.lat, e.latlng.lng);
      this.#view.setMapMarker(e.latlng, "Lokasi Anda saat ini");
    });

    map.on("locationerror", () => {
      console.warn("Tidak bisa mendapatkan lokasi.");
    });

    map.locate({ setView: true, maxZoom: 16 });

    this.#view.setMapInstance(map);
  }
}

export default AddStoryPresenter;
